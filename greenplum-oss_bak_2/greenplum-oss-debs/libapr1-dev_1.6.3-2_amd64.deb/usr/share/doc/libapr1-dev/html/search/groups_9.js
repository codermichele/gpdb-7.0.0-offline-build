var searchData=
[
  ['miscellaneous_20library_20routines',['Miscellaneous library routines',['../group__apr__general.html',1,'']]],
  ['mmap_20_28memory_20map_29_20routines',['MMAP (Memory Map) Routines',['../group__apr__mmap.html',1,'']]],
  ['memory_20pool_20functions',['Memory Pool Functions',['../group__apr__pools.html',1,'']]]
];
