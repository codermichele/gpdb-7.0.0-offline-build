var searchData=
[
  ['user_20and_20group_20id_20services',['User and Group ID Services',['../group__apr__user.html',1,'']]],
  ['user',['user',['../structapr__finfo__t.html#ab79d14bd50f50662d29ad433166c4bc5',1,'apr_finfo_t']]]
];
