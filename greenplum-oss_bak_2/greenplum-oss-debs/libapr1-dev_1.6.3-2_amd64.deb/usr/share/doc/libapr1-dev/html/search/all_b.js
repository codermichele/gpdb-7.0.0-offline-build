var searchData=
[
  ['miscellaneous_20library_20routines',['Miscellaneous library routines',['../group__apr__general.html',1,'']]],
  ['mmap_20_28memory_20map_29_20routines',['MMAP (Memory Map) Routines',['../group__apr__mmap.html',1,'']]],
  ['memory_20pool_20functions',['Memory Pool Functions',['../group__apr__pools.html',1,'']]],
  ['major',['major',['../structapr__version__t.html#a0ae64fee85387834ab76d9f9288373ab',1,'apr_version_t']]],
  ['memmove',['memmove',['../group__apr__general.html#gad12df83f1d3a090b658adc645555ca79',1,'apr_general.h']]],
  ['minor',['minor',['../structapr__version__t.html#aab0a1e8362517416389631bceeeedbad',1,'apr_version_t']]],
  ['mm',['mm',['../structapr__mmap__t.html#abcc62d7e7c8187311e6619faf0d44f19',1,'apr_mmap_t']]],
  ['mtime',['mtime',['../structapr__finfo__t.html#afc3bec0f6b3b10160428ba5602a41c60',1,'apr_finfo_t']]]
];
