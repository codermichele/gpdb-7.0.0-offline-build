var searchData=
[
  ['directory_20manipulation_20functions',['Directory Manipulation Functions',['../group__apr__dir.html',1,'']]],
  ['dynamic_20object_20handling',['Dynamic Object Handling',['../group__apr__dso.html',1,'']]],
  ['dso_20_28dynamic_20loading_29_20portability_20routines',['DSO (Dynamic Loading) Portability Routines',['../group__apr__os__dso.html',1,'']]]
];
