var searchData=
[
  ['other_20child_20flags',['Other Child Flags',['../group___a_p_r___o_c.html',1,'']]],
  ['object_20permission_20set_20functions',['Object permission set functions',['../group__apr__perms__set.html',1,'']]],
  ['opt',['opt',['../structapr__getopt__t.html#a4f842391b8f8f19e562584fdd29d0654',1,'apr_getopt_t']]],
  ['optch',['optch',['../structapr__getopt__option__t.html#a476e67c4dde620fe5b4f5952238c6e94',1,'apr_getopt_option_t']]],
  ['os_5fsock',['os_sock',['../structapr__os__sock__info__t.html#a952464d2f91ca4650e8b4848a81745b5',1,'apr_os_sock_info_t']]],
  ['out',['out',['../structapr__proc__t.html#acb7d7c5226217946d761f0e90ff70d24',1,'apr_proc_t']]]
];
