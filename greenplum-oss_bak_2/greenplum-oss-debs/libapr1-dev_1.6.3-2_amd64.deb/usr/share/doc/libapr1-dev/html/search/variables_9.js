var searchData=
[
  ['local',['local',['../structapr__os__sock__info__t.html#afaf470560cbc3088479af708878aa086',1,'apr_os_sock_info_t']]]
];
