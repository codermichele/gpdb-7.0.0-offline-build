def awesome_stuff():
    pass
