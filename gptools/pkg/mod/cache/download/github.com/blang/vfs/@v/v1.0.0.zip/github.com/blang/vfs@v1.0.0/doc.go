// Package vfs defines an abstract file system and various implementations.
package vfs
