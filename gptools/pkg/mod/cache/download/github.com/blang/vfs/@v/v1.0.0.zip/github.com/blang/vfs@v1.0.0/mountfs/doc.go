// Package mountfs defines a filesystem supporting
// the composition of multiple filesystems by mountpoints.
package mountfs
