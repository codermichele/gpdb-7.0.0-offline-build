# gp-common-go-libs [![Concourse Build Status](https://prod.ci.gpdb.pivotal.io/api/v1/teams/main/pipelines/gp-common-go-libs/badge)] 

Pipeline lives [here](https://prod.ci.gpdb.pivotal.io/teams/main/pipelines/gp-common-go-libs)
