package table

type TableSupportHasBeenMovedToTheCoreGinkgoDSL struct{}
